How To Use :
- Drop generated file from UFT SDK Generator in "UftCppUnitTests" Directory (same dir that have "pch.cpp").
- In VisualStudio View->Test Explore.